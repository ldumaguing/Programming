#!/usr/bin/env perl

use strict;
use warnings;
use diagnostics;

use v5.42;

my $line = "";
my $stmt = "";

my $modeNum = 0;

# Game map B1 is 0,0.

# ***************************************************************************************
use DBI;
my $conn = DBI->connect( "dbi:SQLite:dbname=db/TLR.db", "", "" );

my $filename  = $ARGV[0];
my $fname     = $filename;
my $letterRef = ord('A') + 1;

$fname =~ s/db\///;
$fname =~ s/\.txt//;

if ( defined $filename ) {
    slurp();
}
else {
    say "empty";
}

$conn->disconnect();

# *********************************************************
sub slurp {
    open my $fh, '<', $filename or die "Cannot open $filename: $!";

    while ( $line = <$fh> ) {
        chomp $line;    # Remove trailing newline character
        last if ( $line =~ /END/ );

        if ( $line =~ /^$/ )              { $modeNum = 0;  next; }
        if ( $line =~ /^HILL \*/ )        { $modeNum = 1;  next; }
        if ( $line =~ /^ROAD \*/ )        { $modeNum = 2;  next; }
        if ( $line =~ /^RIVER \*/ )       { $modeNum = 3;  next; }
        if ( $line =~ /^TUNNEL ROAD \*/ ) { $modeNum = 4;  next; }
        if ( $line =~ /^ROLLING \*/ )     { $modeNum = 5;  next; }
        if ( $line =~ /^FOREST \*/ )      { $modeNum = 6;  next; }
        if ( $line =~ /^TOWN \*/ )        { $modeNum = 7;  next; }
        if ( $line =~ /^CITY \*/ )        { $modeNum = 8;  next; }
        if ( $line =~ /^CULTIVATED \*/ )  { $modeNum = 9;  next; }
        if ( $line =~ /^LAKE \*/ )        { $modeNum = 10; next; }
        if ( $line =~ /^BRIDGE \*/ )      { $modeNum = 11; next; }

        if ( $modeNum == 1 )  { register_hill(); }
        if ( $modeNum == 2 )  { register_road(); }
        if ( $modeNum == 3 )  { register_river(); }
        if ( $modeNum == 4 )  { register_tunnel_road(); }
        if ( $modeNum == 5 )  { register_rolling(); }
        if ( $modeNum == 6 )  { register_forest(); }
        if ( $modeNum == 7 )  { register_town(); }
        if ( $modeNum == 8 )  { register_city(); }
        if ( $modeNum == 9 )  { register_cultivated(); }
        if ( $modeNum == 10 ) { register_lake(); }
        if ( $modeNum == 11 ) { register_bridge(); }
    }

    close $fh;
}

# *********************************************************
sub register_lake {
    $line =~ tr/[a-z]/[A-Z]/;
    my $rs = undef;

    my @hexes = split /,/, $line;
    foreach my $hexID (@hexes) {
        $stmt =
            "UPDATE terrain set flag2 = (flag2 | (1 << 2)) WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "hexID = '"
          . $hexID . "'";

        $rs = $conn->prepare($stmt);
        $rs->execute();
        $rs->finish();
    }
}

# *********************************************************
sub register_cultivated {
    $line =~ tr/[a-z]/[A-Z]/;
    my $rs = undef;

    my @hexes = split /,/, $line;
    foreach my $hexID (@hexes) {
        $stmt =
            "UPDATE terrain set flag2 = (flag2 | (1 << 1)) WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "hexID = '"
          . $hexID . "'";

        $rs = $conn->prepare($stmt);
        $rs->execute();
        $rs->finish();
    }
}

# *********************************************************
sub register_city {
    $line =~ tr/[a-z]/[A-Z]/;
    my $rs = undef;

    my @hexes = split /,/, $line;
    foreach my $hexID (@hexes) {
        $stmt =
            "UPDATE terrain set flag2 = (flag2 | (1 << 0)) WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "hexID = '"
          . $hexID . "'";

        $rs = $conn->prepare($stmt);
        $rs->execute();
        $rs->finish();
    }
}

# *********************************************************
sub register_town {
    $line =~ tr/[a-z]/[A-Z]/;
    my $rs = undef;

    my @hexes = split /,/, $line;
    foreach my $hexID (@hexes) {
        $stmt =
            "UPDATE terrain set flag1 = (flag1 | (1 << 15)) WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "hexID = '"
          . $hexID . "'";

        $rs = $conn->prepare($stmt);
        $rs->execute();
        $rs->finish();
    }
}

# *********************************************************
sub register_forest {
    $line =~ tr/[a-z]/[A-Z]/;
    my $rs = undef;

    my @hexes = split /,/, $line;
    foreach my $hexID (@hexes) {
        $stmt =
            "UPDATE terrain set flag1 = (flag1 | (1 << 14)) WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "hexID = '"
          . $hexID . "'";

        $rs = $conn->prepare($stmt);
        $rs->execute();
        $rs->finish();
    }
}

# *********************************************************
sub register_rolling {
    $line =~ tr/[a-z]/[A-Z]/;
    my $rs = undef;

    my @hexes = split /,/, $line;
    foreach my $hexID (@hexes) {
        $stmt =
            "UPDATE terrain set flag1 = (flag1 | (1 << 13)) WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "hexID = '"
          . $hexID . "'";

        $rs = $conn->prepare($stmt);
        $rs->execute();
        $rs->finish();
    }
}

# *********************************************************
sub register_tunnel_road {
    my $exits = 0;
    $line =~ tr/[a-z]/[A-Z]/;
    my @hexes = split /:/, $line;

    if ( $hexes[1] =~ /A/ ) { $exits = $exits | ( 1 << 0 ); }
    if ( $hexes[1] =~ /B/ ) { $exits = $exits | ( 1 << 1 ); }
    if ( $hexes[1] =~ /C/ ) { $exits = $exits | ( 1 << 2 ); }
    if ( $hexes[1] =~ /D/ ) { $exits = $exits | ( 1 << 3 ); }
    if ( $hexes[1] =~ /E/ ) { $exits = $exits | ( 1 << 4 ); }
    if ( $hexes[1] =~ /F/ ) { $exits = $exits | ( 1 << 5 ); }
    $exits = $exits << 7;

    $stmt =
        "UPDATE terrain set flag1 = (flag1 | "
      . $exits
      . ") WHERE "
      . "mapFile = '"
      . $fname
      . "' and "
      . "hexID = '"
      . $hexes[0] . "'";

    my $rs = $conn->prepare($stmt);
    $rs->execute();
    $rs->finish();

}

# *********************************************************
sub register_bridge {
    $line =~ tr/[a-z]/[A-Z]/;
    my ( $hex, $spines ) = split /:/, $line;
    my $X = ord( substr( $hex, 0, 1 ) ) - $letterRef;
    my $Y = int( substr( $hex, 1 ) ) - 1;

    if ( $X % 2 ) { odd_X( $hex, $X, $Y, $spines, ( 1 << 1 ) ); }
    else          { even_X( $hex, $X, $Y, $spines, ( 1 << 1 ) ); }
}

# *********************************************************
sub register_river {
    $line =~ tr/[a-z]/[A-Z]/;
    my ( $hex, $spines ) = split /:/, $line;
    my $X = ord( substr( $hex, 0, 1 ) ) - $letterRef;
    my $Y = int( substr( $hex, 1 ) ) - 1;

    if ( $X % 2 ) { odd_X( $hex, $X, $Y, $spines, ( 1 << 0 ) ); }
    else          { even_X( $hex, $X, $Y, $spines, ( 1 << 0 ) ); }
}

# ***************************
sub odd_X {
    my ( $hex, $X, $Y, $spines, $bit ) = @_;
    my $stmt = "";
    my $rs   = undef;

    if ( $spines =~ /A/ ) {
        my $modX = $X - 1;
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $modX . ", "
          . $Y . ", "
          . 4 . ")";

        #say " -." . $stmt;
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $modX . " and "
          . "loc_y = "
          . $Y . " and "
          . "spine = 4";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }

    if ( $spines =~ /B/ ) {
        my $modX = $X + 1;
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $modX . ", "
          . $Y . ", "
          . 5 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $modX . " and "
          . "loc_y = "
          . $Y . " and "
          . "spine = 5";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }

    if ( $spines =~ /C/ ) {
        my $modX = $X + 1;
        my $modY = $Y + 1;
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $modX . ", "
          . $modY . ", "
          . 6 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $modX . " and "
          . "loc_y = "
          . $modY . " and "
          . "spine = 6";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }

    if ( $spines =~ /D/ ) {
        my $modX = $X - 1;
        my $modY = $Y + 1;
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $modX . ", "
          . $modY . ", "
          . 4 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $modX . " and "
          . "loc_y = "
          . $modY . " and "
          . "spine = 4";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }

    if ( $spines =~ /E/ ) {
        my $modX = $X - 1;
        my $modY = $Y + 1;
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $modX . ", "
          . $modY . ", "
          . 2 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $modX . " and "
          . "loc_y = "
          . $modY . " and "
          . "spine = 2";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }

    if ( $spines =~ /F/ ) {
        my $modX = $X - 1;
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $modX . ", "
          . $Y . ", "
          . 3 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $modX . " and "
          . "loc_y = "
          . $Y . " and "
          . "spine = 3";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }
}

# ***************************
sub even_X {
    my ( $hex, $X, $Y, $spines, $bit ) = @_;
    my $stmt = "";
    my $rs   = undef;

    if ( $spines =~ /A/ ) {
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $X . ", "
          . $Y . ", "
          . 1 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $X . " and "
          . "loc_y = "
          . $Y . " and "
          . "spine = 1";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }

    if ( $spines =~ /B/ ) {
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $X . ", "
          . $Y . ", "
          . 2 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $X . " and "
          . "loc_y = "
          . $Y . " and "
          . "spine = 2";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }

    if ( $spines =~ /C/ ) {
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $X . ", "
          . $Y . ", "
          . 3 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $X . " and "
          . "loc_y = "
          . $Y . " and "
          . "spine = 3";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }

    if ( $spines =~ /D/ ) {
        my $modY = $Y + 1;
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $X . ", "
          . $modY . ", "
          . 1 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $X . " and "
          . "loc_y = "
          . $modY . " and "
          . "spine = 1";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }

    if ( $spines =~ /E/ ) {
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $X . ", "
          . $Y . ", "
          . 5 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $X . " and "
          . "loc_y = "
          . $Y . " and "
          . "spine = 5";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }

    if ( $spines =~ /F/ ) {
        $stmt =
            "INSERT INTO spine (mapFile, loc_x, loc_y, spine) VALUES (" . "'"
          . $fname . "', "
          . $X . ", "
          . $Y . ", "
          . 6 . ")";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $stmt =
            "UPDATE spine set flag1 = (flag1 | "
          . $bit
          . ") WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "loc_x = "
          . $X . " and "
          . "loc_y = "
          . $Y . " and "
          . "spine = 6";
        $rs = $conn->prepare($stmt);
        $rs->execute();

        $rs->finish();
    }
}

# *********************************************************
sub register_road {
    my $exits = 0;
    $line =~ tr/[a-z]/[A-Z]/;
    my @hexes = split /:/, $line;

    if ( $hexes[1] =~ /A/ ) { $exits = $exits | ( 1 << 0 ); }
    if ( $hexes[1] =~ /B/ ) { $exits = $exits | ( 1 << 1 ); }
    if ( $hexes[1] =~ /C/ ) { $exits = $exits | ( 1 << 2 ); }
    if ( $hexes[1] =~ /D/ ) { $exits = $exits | ( 1 << 3 ); }
    if ( $hexes[1] =~ /E/ ) { $exits = $exits | ( 1 << 4 ); }
    if ( $hexes[1] =~ /F/ ) { $exits = $exits | ( 1 << 5 ); }
    $exits = $exits << 1;

    $stmt =
        "UPDATE terrain set flag1 = (flag1 | "
      . $exits
      . ") WHERE "
      . "mapFile = '"
      . $fname
      . "' and "
      . "hexID = '"
      . $hexes[0] . "'";

    my $rs = $conn->prepare($stmt);
    $rs->execute();
    $rs->finish();
}

# *********************************************************
sub register_hill {
    $line =~ tr/[a-z]/[A-Z]/;
    my $rs = undef;

    my @hexes = split /,/, $line;
    foreach my $hexID (@hexes) {
        $stmt =
            "UPDATE terrain set flag1 = (flag1 | (1 << 0)) WHERE "
          . "mapFile = '"
          . $fname
          . "' and "
          . "hexID = '"
          . $hexID . "'";

        $rs = $conn->prepare($stmt);
        $rs->execute();
        $rs->finish();
    }
}

