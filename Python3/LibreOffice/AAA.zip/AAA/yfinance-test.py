import yfinance as yf

ticker_symbol = 'AAPL'
stock = yf.Ticker(ticker_symbol)

# Get current price
# The 'regularMarketPrice' or 'last_price' attribute provides the most recent price
current_price = stock.info.get('regularMarketPrice') 

if current_price:
    print(f"{current_price}")
else:
    print(f"Could not retrieve current price for {ticker_symbol}")
