import subprocess
import os
import re



cmd = [
        "/usr/bin/python",
        "/home/ayeka/MyPy/foo.py"
]

result = subprocess.run(cmd, capture_output=True, text=True)
fish = result.stdout
fish = re.sub("\n", "", fish)
print(fish)
#doc = CreateScriptService("Calc")
#doc.setValue("B8", fish)
