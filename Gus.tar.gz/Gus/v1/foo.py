import sqlite3


CONN = sqlite3.connect("inventory.db")

stmt = "SELECT name, serial_num, model, org_unit FROM tanium"
cursor = CONN.cursor()
cursor.execute(stmt)
rows = cursor.fetchall()
for row in rows:
    name = row[0]
    X = name.replace(".bmcc.cuny.edu", "")
    X = X.split("-")
    if len(X) == 3:
        man_num = f"00{X[2]}"
        stmt = f"UPDATE tanium SET man_num = '{man_num}' WHERE "
        stmt += f"name = '{name}'"
        print(stmt)
        cursor.execute(stmt)
        CONN.commit()
    elif len(X) == 1:
        man_num = f"00{X[0]}"
        man_num = man_num.replace("PC", "")
        stmt = f"UPDATE tanium SET man_num = '{man_num}' WHERE "
        stmt += f"name = '{name}'"
        print(stmt)
        cursor.execute(stmt)
        CONN.commit()
    elif len(X) == 2:
        man_num = f"00{X[1]}"
        man_num = man_num.replace("PC", "")
        stmt = f"UPDATE tanium SET man_num = '{man_num}' WHERE "
        stmt += f"name = '{name}'"
        print(stmt)
        cursor.execute(stmt)
        CONN.commit()

cursor.close()
CONN.close()
