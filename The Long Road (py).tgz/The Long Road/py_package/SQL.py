import re


def get_field_value(CONN, stmt):
    cursor = CONN.cursor()
    cursor.execute(stmt)
    CONN.commit()
    rs = cursor.fetchone()
    cursor.close()
    return rs[0]


def is_same_place(conn, scenario_id, unit):
    stmt = "SELECT count(*) FROM instance_unit WHERE "
    stmt += f"id = {unit[0]} "
    stmt += f"AND loc_x = {unit[1]} "
    stmt += f"AND loc_y = {unit[2]} "
    stmt += f"AND scenario_id = {scenario_id}"
    cursor = conn.cursor()
    cursor.execute(stmt)
    conn.commit()
    rs = cursor.fetchone()
    cursor.close()
    return rs[0]


def is_visible(conn, scenario_id, iid):
    stmt = "SELECT * FROM instance_unit WHERE "
    stmt += f"scenario_id = {scenario_id} AND "
    stmt += f"id = {iid} AND "
    stmt += "(status1 & 1)"
    cursor = conn.cursor()
    cursor.execute(stmt)
    rs = cursor.fetchone()
    if rs is None:
        cursor.close()
        return 0
    cursor.close()
    return 1


def get_3columns(conn, stmt):
    stuffs = []
    cursor = conn.cursor()
    cursor.execute(stmt)
    rows = cursor.fetchall()
    for row in rows:
        stuffs.append((row[0], row[1], row[2]))
    return stuffs


def get_2columns(conn, stmt):
    stuffs = []
    cursor = conn.cursor()
    cursor.execute(stmt)
    rows = cursor.fetchall()
    for row in rows:
        stuffs.append((row[0], row[1]))
    return stuffs


def get_combatants(conn, stmt):
    stuffs = []
    cursor = conn.cursor()
    cursor.execute(stmt)
    rows = cursor.fetchall()
    for row in rows:
        stuffs.append((row[0], row[1], row[2], row[3], row[4], row[5]))
    return stuffs


def get_row(conn, scenario_id, fields, table, where):
    stmt = f"SELECT {fields} FROM {table} WHERE scenario_id = {scenario_id}"
    if scenario_id <= 0:
        stmt = f"SELECT {fields} FROM {table} WHERE {where}"
    elif re.search(".", where):
        stmt += f" AND {where}"
    cursor = conn.cursor()
    cursor.execute(stmt)
    conn.commit()
    rs = cursor.fetchone()
    cursor.close()
    return rs


def execute_sql(conn, stmt):
    cursor = conn.cursor()
    cursor.execute(stmt)
    conn.commit()
    cursor.close()


def get_imgs(conn, scenario_id):
    # get imgs used in the game
    stuffs = []
    stmt = f"SELECT file, img_id FROM instance_unit WHERE scenario_id = {scenario_id}"
    cursor = conn.cursor()
    cursor.execute(stmt)
    rows = cursor.fetchall()
    for row in rows:
        X = f"{row[0]}:{row[1]}"
        stuffs.append(X)

    uniqs = list(set(stuffs))

    cursor.close()

    return uniqs
