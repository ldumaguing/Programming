<?php

declare(strict_types=1);

/**
 * Authenticates a user against an LDAP / Active Directory server.
 * 
 * @param string $username The user-provided login identifier (e.g., samAccountName or mail).
 * @param string $password The user-provided password.
 * @return bool True if authentication succeeds, false otherwise.
 */
function authenticateUser(string $username, string $password): bool 
{
    // 1. Connection Configurations
    $ldapHost = 'ldap://VSRODC19MB01.bmcc.cuny.edu'; // Use ldaps:// for port 636 or ldap:// for 389
    $ldapPort = 389; 
    $baseDn   = 'dc=bmcc,dc=cuny,dc=edu';
    
    // Service account details needed to search for the user's full DN
    $serviceUuid = 'CN=Service Account,OU=Services,DC=yourdomain,DC=local';
    $servicePassword = 'YourSecureServicePassword';

    if (empty($username) || empty($password)) {
        return false;
    }

    // 2. Initialize Connection
    $ldapConn = ldap_connect($ldapHost, $ldapPort);
    if (!$ldapConn instanceof \LDAP\Connection) { // PHP 8.x object validation
        return false;
    }

    // 3. Configure Protocol Options
    ldap_set_option($ldapConn, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($ldapConn, LDAP_OPT_REFERRALS, 0); // Crucial for Active Directory compatibility

    try {
        // 4. Bind with Service Account to query the directory
        $serviceBind = @ldap_bind($ldapConn, $serviceUuid, $servicePassword);
        if (!$serviceBind) {
            throw new Exception("Service account bind failed.");
        }

        // 5. Search for the target user entry to get their unique DN
        // Sanitizing the username input prevents LDAP injection vulnerabilities
        $sanitizedUser = ldap_escape($username, "", LDAP_ESCAPE_FILTER);
        $searchFilter = "(uid={$sanitizedUser})"; // Use "(sAMAccountName={$sanitizedUser})" for Active Directory
        
        $searchResult = @ldap_search($ldapConn, $baseDn, $searchFilter, ['dn']);
        if (!$searchResult instanceof \LDAP\Result || ldap_count_entries($ldapConn, $searchResult) !== 1) {
            return false; // User not found, or multiple users found
        }

        // 6. Extract the user's Distinguished Name (DN)
        $entry = ldap_first_entry($ldapConn, $searchResult);
        if (!$entry instanceof \LDAP\ResultEntry) {
            return false;
        }
        
        $userDn = ldap_get_dn($ldapConn, $entry);
        if ($userDn === false) {
            return false;
        }

        // 7. Verify credentials by attempting a re-bind with the User's DN and Password
        $userBind = @ldap_bind($ldapConn, $userDn, $password);
        if ($userBind) {
            return true; // Authentication successful!
        }

    } catch (\Throwable $e) {
        // Log errors securely according to your application infrastructure
        error_log("LDAP Auth Error: " . $e->getMessage());
    } finally {
        // 8. Always close connections gracefully
        @ldap_close($ldapConn);
    }

    return false;
}

// Example Usage
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (authenticateUser($username, $password)) {
    echo "Access granted.";
} else {
    echo "Invalid username or password.";
}

