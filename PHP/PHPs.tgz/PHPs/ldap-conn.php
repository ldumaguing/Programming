<?php
$ldapconn = ldap_connect("ldap://vsrodc19mb01.bmcc.cuny.edu")
    or die("Could not connect to LDAP server.");

if ($ldapconn) {
    // binding anonymously
    $ldapbind = ldap_bind($ldapconn);

    if ($ldapbind) {
        echo "LDAP bind anonymous successful...";
    } else {
        echo "LDAP bind anonymous failed...";
    }
}
?>

