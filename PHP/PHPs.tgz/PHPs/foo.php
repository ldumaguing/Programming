<?php

// LDAP variables
$ldapuri = "ldap://vsrodc19mb01.bmcc.cuny.edu:389";  // your ldap-uri

// Connecting to LDAP
$ldapconn = ldap_connect($ldapuri)
          or die("That LDAP-URI was not parseable");

?>
