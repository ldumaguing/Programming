<?php
session_start();
echo "-session:  " . $_SESSION['mine'] . "<br>";
echo "username: " . $_SESSION['fname'] . "<br>";
echo "session:  " . session_id() . "<br>";
echo "---1 " . $_SERVER['PHP_AUTH_USER'] . "<br>";





foreach ($_COOKIE as $name => $value) {
        $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
        $safeValue = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
        echo "<br>Cookie Name: $safeName | Value: $safeValue <br>";
    }

echo "<br>";


$a = $_SESSION['mine']; 
$b = session_id();

if ($a !== $b)
	header("Location: fish.php");





$_SERVER['PHP_AUTH_PW'] = 'xxx';





$_COOKIE['PHPSESSID'] = '';


$_SESSION = array();
$params = session_get_cookie_params();
setcookie(session_name(), '', time() - 2592000, $params['path']);
session_destroy();


unset($_SERVER['PHP_AUTH_USER']);
unset($_SERVER['PHP_AUTH_PW']);








echo "<br><br>";
echo "username: " . $_SESSION['fname'] . "<br>";
echo "session:  " . session_id() . "<br>";

die ("..........");





?>
