<!DOCTYPE html>
<html lang="en">
   <head>
      <title>A quick test</title>
   </head>
   <body>
      Hello World!
<?php
    echo "yo";
?>
   </body>
</html>

